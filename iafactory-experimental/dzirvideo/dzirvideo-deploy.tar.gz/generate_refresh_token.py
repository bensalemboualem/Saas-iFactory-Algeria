#!/usr/bin/env python3
"""
Generate YouTube OAuth Refresh Token for DzirVideo
Desktop App Flow - No redirect URI needed
"""

from google_auth_oauthlib.flow import InstalledAppFlow
import json

# YouTube upload scope
SCOPES = ['https://www.googleapis.com/auth/youtube.upload']

# OAuth credentials (Application Web - avec redirect URIs configurés)
CLIENT_ID = "448014029270-jnn9kgpiljvutf7b24qq8bj4nsgli954.apps.googleusercontent.com"
CLIENT_SECRET = "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"

def main():
    print("=" * 60)
    print("GÉNÉRATION REFRESH TOKEN YOUTUBE - DzirVideo")
    print("=" * 60)
    print()

    # Create client config (Web Application type)
    client_config = {
        "web": {
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET,
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token",
            "redirect_uris": ["http://localhost:8080/"]
        }
    }

    print("1. Un navigateur va s'ouvrir automatiquement")
    print("2. Connecte-toi avec : bensalemboualem@gmail.com")
    print("3. Accepte les permissions YouTube")
    print("4. Le refresh token s'affichera ici")
    print()
    print("⏳ Ouverture du navigateur dans 3 secondes...")
    print()

    try:
        # Run the OAuth flow
        flow = InstalledAppFlow.from_client_config(
            client_config,
            scopes=SCOPES
        )

        # This will open a browser window
        credentials = flow.run_local_server(
            port=8080,
            success_message='✅ Authentification réussie! Tu peux fermer cette fenêtre.',
            open_browser=True
        )

        print()
        print("=" * 60)
        print("✅ SUCCÈS ! Voici ton REFRESH TOKEN :")
        print("=" * 60)
        print()
        print(credentials.refresh_token)
        print()
        print("=" * 60)
        print()
        print("📋 INSTRUCTIONS :")
        print("1. COPIE le token ci-dessus (commence par 1//...)")
        print("2. Envoie-le à Claude pour qu'il update le VPS")
        print("3. C'est tout ! 🎬")
        print()

        # Save to file for easy copy
        with open('REFRESH_TOKEN.txt', 'w') as f:
            f.write(credentials.refresh_token)
        print("💾 Token sauvegardé aussi dans: REFRESH_TOKEN.txt")
        print()

    except Exception as e:
        print()
        print(f"❌ ERREUR : {e}")
        print()
        print("SOLUTIONS :")
        print("- Vérifie que ton email est dans 'utilisateurs tests'")
        print("- Essaie de désactiver ton antivirus temporairement")
        print("- Vérifie que le port 8080 est libre")
        print()

if __name__ == "__main__":
    main()
