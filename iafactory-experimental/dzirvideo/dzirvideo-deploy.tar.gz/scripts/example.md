# Exemple de Script pour DzirVideo

Bonjour à tous! Aujourd'hui, je vous présente un outil incroyable pour automatiser la création de vidéos YouTube Shorts.

Avec DzirVideo, vous pouvez générer des vidéos en quelques secondes. Il suffit d'écrire votre script, et l'outil s'occupe du reste: génération audio, sous-titres automatiques, et mise en ligne sur YouTube.

C'est simple, rapide, et 100% open-source. Essayez-le dès maintenant!
