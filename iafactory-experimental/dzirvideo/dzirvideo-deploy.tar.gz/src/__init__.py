# DzirVideo - YouTube Shorts Automation
__version__ = "1.0.0"
