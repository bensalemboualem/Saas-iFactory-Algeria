"""
Dzir IA Video PRO - FastAPI Server with AI Assistant
REST API for professional video generation with AI script optimization
"""

from fastapi import FastAPI, File, UploadFile, Form, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import logging
from pathlib import Path
import tempfile
import os

from .pipeline import VideoPipeline
from .ai_assistant.script_optimizer import ScriptOptimizer

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

app = FastAPI(
    title="Dzir IA Video PRO API",
    description="Professional YouTube Shorts generation with AI script optimization and multi-AI generators",
    version="2.1.0"
)

# Mount static directories
app.mount("/output", StaticFiles(directory="output"), name="output")

# Initialize services
pipeline = VideoPipeline()
ai_optimizer = ScriptOptimizer(api_key=os.getenv("CLAUDE_API_KEY"))


# ===== Models =====

class VideoRequest(BaseModel):
    """Video generation request"""
    script_text: str
    title: str
    description: str = ""
    tags: list[str] = []
    publish: bool = False
    privacy_status: str = "public"


class ScriptOptimizationRequest(BaseModel):
    """AI script optimization request"""
    raw_idea: str
    niche: str = "general"  # tech, business, education, motivation, etc.
    tone: str = "energetic"  # energetic, calm, professional, funny
    target_duration: int = 45  # seconds


class ScriptAnalysisRequest(BaseModel):
    """Script analysis request"""
    script: str


# ===== Endpoints =====

@app.get("/")
async def root():
    """Serve PRO web interface"""
    return FileResponse("public/index-pro.html")


@app.get("/api")
async def api_info():
    """API information (JSON)"""
    return {
        "service": "Dzir IA Video PRO",
        "version": "2.1.0",
        "status": "running",
        "features": {
            "ai_script_optimization": True,
            "script_analysis": True,
            "professional_editing": True,
            "youtube_upload": True
        },
        "endpoints": {
            "health": "/health",
            "generate": "POST /generate",
            "ai_optimize": "POST /ai/optimize-script",
            "ai_analyze": "POST /ai/analyze-script",
            "status": "/status"
        }
    }


@app.get("/health")
async def health():
    """Health check endpoint"""
    return {"status": "healthy", "service": "dzir-ia-video-pro"}


# ===== AI Endpoints =====

@app.post("/ai/optimize-script")
async def optimize_script(request: ScriptOptimizationRequest):
    """
    AI-powered script optimization

    Transforms raw idea into viral YouTube Short script with:
    - Attention-grabbing hook (first 3 seconds)
    - Engaging main content
    - Strong call-to-action
    - Optimized title, description, tags
    - Viral score prediction
    """
    try:
        result = ai_optimizer.optimize_script(
            raw_idea=request.raw_idea,
            niche=request.niche,
            tone=request.tone,
            target_duration=request.target_duration
        )

        return {
            "success": True,
            "hook": result.hook,
            "main_content": result.main_content,
            "cta": result.cta,
            "full_script": result.full_script,
            "title": result.title,
            "description": result.description,
            "tags": result.tags,
            "viral_score": result.viral_score,
            "improvements": result.improvements
        }

    except Exception as e:
        logging.error(f"AI optimization error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/ai/analyze-script")
async def analyze_script(request: ScriptAnalysisRequest):
    """
    Analyze existing script and provide optimization suggestions

    Returns:
    - Word count, character count, estimated duration
    - Hook analysis, CTA detection
    - Viral score prediction
    - Improvement suggestions
    """
    try:
        analysis = ai_optimizer.analyze_script(request.script)

        return {
            "success": True,
            **analysis
        }

    except Exception as e:
        logging.error(f"Script analysis error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ===== Video Generation Endpoints =====

@app.post("/generate")
async def generate_video(request: VideoRequest):
    """
    Generate video from script text

    Args:
        request: VideoRequest with script, title, etc.

    Returns:
        JSON with video details and paths
    """
    try:
        result = pipeline.run_full_pipeline(
            script_text=request.script_text,
            title=request.title,
            description=request.description,
            tags=request.tags,
            publish=request.publish,
            privacy_status=request.privacy_status
        )

        return JSONResponse(content=result)

    except Exception as e:
        logging.error(f"Error generating video: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/generate/file")
async def generate_from_file(
    script_file: UploadFile = File(...),
    title: str = Form(...),
    description: str = Form(""),
    tags: str = Form(""),  # Comma-separated
    publish: bool = Form(False),
    privacy_status: str = Form("public")
):
    """
    Generate video from uploaded script file (.md or .txt)

    Args:
        script_file: Script file (markdown or text)
        title: Video title
        description: Video description
        tags: Comma-separated tags
        publish: Whether to publish to YouTube
        privacy_status: YouTube privacy status

    Returns:
        JSON with video details
    """
    try:
        # Read script content
        content = await script_file.read()
        script_text = content.decode('utf-8')

        # Parse tags
        tags_list = [t.strip() for t in tags.split(',') if t.strip()]

        # Generate video
        result = pipeline.run_full_pipeline(
            script_text=script_text,
            title=title,
            description=description,
            tags=tags_list,
            publish=publish,
            privacy_status=privacy_status
        )

        return JSONResponse(content=result)

    except Exception as e:
        logging.error(f"Error generating video from file: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/download/{filename}")
async def download_video(filename: str):
    """
    Download generated video

    Args:
        filename: Video filename

    Returns:
        Video file
    """
    video_path = Path("./output/videos") / filename

    if not video_path.exists():
        raise HTTPException(status_code=404, detail="Video not found")

    return FileResponse(
        path=video_path,
        media_type="video/mp4",
        filename=filename
    )


@app.get("/status")
async def get_status():
    """Get pipeline status and configuration"""
    return {
        "pipeline": "ready",
        "ai_assistant": "enabled" if ai_optimizer.api_key else "disabled (fallback mode)",
        "config": {
            "tts_model": pipeline.config.get('tts_model'),
            "subtitle_style": pipeline.config.get('subtitle_style'),
            "video_resolution": f"{pipeline.config.get('video_width')}x{pipeline.config.get('video_height')}",
            "fps": pipeline.config.get('video_fps')
        },
        "youtube_configured": bool(
            pipeline.config.get('youtube_client_id') and
            pipeline.config.get('youtube_refresh_token')
        )
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8200)
