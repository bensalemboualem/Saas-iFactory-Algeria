"""
Image-to-Video Generators
1 tool for animating static images into videos
"""

from .stable_video_diffusion import StableVideoDiffusionGenerator

__all__ = [
    "StableVideoDiffusionGenerator",
]
