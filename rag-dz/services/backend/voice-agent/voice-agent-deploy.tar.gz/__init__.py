"""
Voice Agent Module with Faster-Whisper
Reconnaissance vocale souveraine multi-langues (FR, EN, AR, Darija)
"""

__version__ = "1.0.0"
